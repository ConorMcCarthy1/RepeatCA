import React from "react";

const FavoriteMoviesPage = () => {
    return <h2>Favorite Movies</h2>
}

export default FavoriteMoviesPage
